#created this init.py to add components as own package (local package)
# --> from src.DiamondPrediction.components.data_ingestion import some class/method