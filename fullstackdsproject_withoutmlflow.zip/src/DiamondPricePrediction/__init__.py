#created this init.py to add src as own package  (local package)
#why we do this inorder to send for testing (QA)

#pip install .
#install through requirements.txt by adding -e .
#through setup.py file by command python setup.py install