```
git init
```

```
git add abc.txt
git add .
```
```
git commit -m "added git commands"
```

```

git pull

```
